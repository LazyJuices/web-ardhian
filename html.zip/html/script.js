document.addEventListener("DOMContentLoaded", function() {
    const navLinks = document.querySelectorAll('.nav-link');
    const logoLink = document.querySelector('.logo-link');
    var currentDomain = window.location.hostname;
    var welcomeText = document.querySelector('.hero-text p:last-of-type');
    welcomeText.textContent = "Welcome to " + currentDomain + ".";
    // Scroll to section when navigation link is clicked
    navLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            // Check if the link is an in-page anchor (starts with #)
            if (this.getAttribute('href').startsWith('#')) {
                event.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);

                // Smooth scroll to the target section if the element exists
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });

    // Scroll back to top when the logo is clicked
    logoLink.addEventListener('click', function(event) {
        event.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});
